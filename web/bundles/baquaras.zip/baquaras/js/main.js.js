
$(document).ready(function(){
	alert("lol");
});
				$("#accordion_package").hide();
				$("#accordion_qualif").hide();
				$("#accordion_maj").hide();
				$("#accordion_hdm").hide();
				$("#infos_appli_onglet").css("color","white");
				$("#infos_appli_onglet").css("background","#444444");
				$("#infos_appli_onglet a:hover").css("color","#444444");